# Testing and Quality Gates

## Run locally

```bash
python -m unittest discover -s tests -v
python -m compileall -q reposentry tests
python -m pip wheel --no-deps --no-build-isolation . -w dist
# CI also runs: python -m build && pip-audit .
```

The test suite uses synthetic data only; no real secrets are required.

## Test coverage

- Positive and negative fixture for every detection rule.
- Safe documentation examples and Terraform comment/string false positives.
- Rule enable/disable and severity overrides.
- TOML parsing, malformed input, unknown rules, hard size limit, path traversal rejection, active and expired suppressions.
- JSON determinism/redaction and SARIF structure, location, URI escaping, severity, and fingerprints.
- CLI exit codes, report output, and malformed configuration handling.
- Git staged index snapshots, staged-vs-working content mismatch, unstaged files, untracked files, deleted files, renamed destinations, and non-Git paths.
- Binary/oversized/invalid UTF-8 files, BOM, CRLF, symlinks, file-count limits, and path normalization.

## Manual smoke tests

```bash
reposentry scan . --no-config
reposentry scan . --format json --output reports/report.json
reposentry scan . --format sarif --output reports/report.sarif
reposentry diff --staged --no-config
reposentry diff --working-tree --no-config
```

## CI gates

- Unit and integration tests on Ubuntu, Windows, and macOS with Python 3.11–3.13.
- Bytecode compilation.
- Wheel build and archive inspection.
- `pip-audit` against project dependency metadata.

SARIF tests validate the structural subset emitted by RepoSentry. Before relying on GitHub code-scanning uploads, test the file against GitHub's accepted SARIF 2.1.0 subset or a schema validator in the release pipeline.

## Known test gaps

- The suite does not measure precision/recall against a large labeled real-world corpus.
- Permission tests are platform-dependent and not all permission failures are deterministic under administrator/root accounts.
- The Git tests use temporary repositories and local Git; they do not test every Git version or unusual filesystem encoding.
