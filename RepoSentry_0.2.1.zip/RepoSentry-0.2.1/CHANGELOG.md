# Changelog

## 0.2.1 — SARIF source-root compatibility
- Added an explicit SARIF source-root URI base and linked relative artifact locations to it for more reliable SARIF consumers.
- Added CLI source-root resolution for directory scans, single-file scans, and Git diff scans.


## 0.2.0 — Reliability and developer workflow
- Added strict, size-bounded TOML configuration using Python's standard library.
- Added rule enable/disable, severity overrides, path ignores, scan limits, and expiring suppressions with required rationale.
- Reworked rule definitions and improved Terraform ingress block matching to reduce comment/string false positives.
- Added normalized paths, stable fingerprints, terminal-control escaping, deterministic JSON, and richer SARIF 2.1.0 metadata.
- Added Git staged/index and working-tree/untracked scanning, including rename/deletion handling and bounded Git subprocess calls.
- Added optional pre-commit hook manifest and setup guidance.
- Added positive/negative fixtures, CLI/config/Git/reporting/hardening tests, and cross-platform CI.
- Updated threat model, architecture, testing, usage, and limitations documentation.

## 0.1.0 — Initial MVP
- Added local CLI scanner with six heuristic rules.
- Added text, JSON, and SARIF reporting.
- Added severity-based exit behavior and initial tests.
