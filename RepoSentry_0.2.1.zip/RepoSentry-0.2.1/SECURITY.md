# Security Policy and Threat Model

RepoSentry is an alpha heuristic scanner. It must not be the only security control protecting a repository or production system.

## Threat model

### Assets
- Developer source code and configuration files
- Credential values present in files
- CI job integrity and exit status
- Finding paths, metadata, and reports

### Trust boundaries
- Repository files and filenames are untrusted input.
- `.reposentry.toml` is user-controlled policy input and may be malformed.
- Git metadata and filenames may contain unusual characters.
- CI configuration and third-party actions are part of the supply chain.

### Security goals
- Do not execute scanned code.
- Do not disclose matched credential values in reports.
- Bound memory/CPU exposure from files and configuration.
- Avoid following symlinks outside the requested repository.
- Avoid shell injection in Git integration.
- Escape terminal controls in paths.
- Fail explicitly for invalid configuration and Git errors rather than silently treating them as a clean scan.

## Safeguards implemented

- Local-only operation; no network calls from RepoSentry itself.
- Python standard library at runtime; no third-party runtime dependencies.
- TOML input limited to 64 KiB, with strict known-key/rule validation.
- File size limit configurable up to a hard 10 MiB cap; total bytes, file count, and line length are bounded.
- UTF-8 decoding is strict (optional BOM accepted); binary and invalid-encoding files are skipped.
- Symbolic links are skipped; resolved paths are constrained to the scan root.
- Git commands use `subprocess.run` with argument arrays, no shell, `--no-ext-diff`, a 30-second timeout, and disable the `core.fsmonitor` hook setting to avoid invoking a repository-configured filesystem monitor.
- Staged content is read from index blobs after size checks; symlink/submodule index modes are skipped.
- Finding messages do not include matched values.
- Terminal control/format characters in displayed paths are escaped.
- Suppressions require a reason and expiry; expired suppressions no longer suppress.
- CI tests on Linux, Windows, and macOS; packaging and dependency-audit checks run separately.

## Known limitations and residual risks

- Heuristic checks have false positives and false negatives; they are not full parsers for each language.
- RS002 flags a private-key header but does not validate key contents.
- Git diff scans complete changed-file snapshots, so an older finding in a modified file may be shown; this preserves multiline detection.
- Binary, over-limit, invalid UTF-8, and symlink files are skipped. Users should not interpret skipped files as clean.
- A local scan cannot prevent a developer from bypassing pre-commit hooks; enforce policies in protected CI workflows.
- Git configuration and repository internals are handled by Git itself. RepoSentry avoids shell interpolation and external diff execution but is not a sandbox for a compromised Git executable.
- TOCTOU races on a concurrently modified filesystem cannot be eliminated completely.
- Git history, remote repositories, dependency CVEs, binaries, and cloud resources are not scanned.
- Fingerprints are intended for stable deduplication, not cryptographic proof of a finding.

## Credential response

If a real credential is detected, treat it as compromised: revoke or rotate it, investigate use, and remove it from current code and repository history as appropriate. Removing a line does not invalidate a leaked credential.

## Reporting vulnerabilities

Please report suspected vulnerabilities privately to the maintainer before public disclosure. Add a project-specific security contact before publishing an official release.
