import contextlib
import io
import subprocess
import tempfile
import unittest
from pathlib import Path
from reposentry.cli import main

class CLITests(unittest.TestCase):
    def test_scan_success_and_severity_exit_code(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text("DEBUG = True\n", encoding="utf-8")
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                code = main(["scan", str(root), "--fail-on", "high"])
            self.assertEqual(code, 0)
            self.assertIn("RS004", stdout.getvalue())
            with contextlib.redirect_stdout(io.StringIO()):
                code = main(["scan", str(root), "--fail-on", "medium"])
            self.assertEqual(code, 1)

    def test_malformed_config_returns_error_code_two(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "bad.toml").write_text("[scan\n", encoding="utf-8")
            stderr = io.StringIO()
            with contextlib.redirect_stderr(stderr):
                code = main(["scan", str(root), "--config", str(root / "bad.toml")])
            self.assertEqual(code, 2)
            self.assertIn("RepoSentry error", stderr.getvalue())

    def test_auto_discovers_repository_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / ".reposentry.toml").write_text('[rules]\ndisabled = ["RS004"]\n', encoding="utf-8")
            (root / "app.py").write_text("DEBUG = True\n", encoding="utf-8")
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                code = main(["scan", str(root), "--fail-on", "medium"])
            self.assertEqual(code, 0)
            self.assertIn("No findings", stdout.getvalue())

    def test_unknown_allow_rule_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            stderr = io.StringIO()
            with contextlib.redirect_stderr(stderr):
                code = main(["scan", tmp, "--allow-rule", "RS999", "--no-config"])
            self.assertEqual(code, 2)
            self.assertIn("Unknown rule ID", stderr.getvalue())

    def test_diff_cli_scans_staged_index(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            def git(*args):
                subprocess.run(["git", "-C", str(root), *args], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            git("init", "-q")
            git("config", "user.email", "test@example.invalid")
            git("config", "user.name", "RepoSentry Test")
            (root / "app.py").write_text("DEBUG = False\n", encoding="utf-8")
            git("add", "app.py")
            git("commit", "-qm", "baseline")
            (root / "app.py").write_text("DEBUG = True\n", encoding="utf-8")
            git("add", "app.py")
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                code = main(["diff", str(root), "--staged", "--no-config", "--fail-on", "medium"])
            self.assertEqual(code, 1)
            self.assertIn("RS004", stdout.getvalue())

    def test_json_report_output_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text("DEBUG = True\n", encoding="utf-8")
            output = root / "reports" / "scan.json"
            with contextlib.redirect_stdout(io.StringIO()):
                code = main(["scan", str(root), "--format", "json", "--output", str(output), "--fail-on", "critical"])
            self.assertEqual(code, 0)
            self.assertTrue(output.is_file())
            self.assertIn('"finding_count": 1', output.read_text(encoding="utf-8"))

if __name__ == "__main__": unittest.main()
