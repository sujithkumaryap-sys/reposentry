import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path
from reposentry.config import ConfigurationError, load_config
from reposentry.rules import RULE_BY_ID, scan_content

class ConfigTests(unittest.TestCase):
    def write_config(self, text):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        path = Path(temp.name) / ".reposentry.toml"
        path.write_text(text, encoding="utf-8")
        return path

    def test_loads_rules_limits_and_ignore_paths(self):
        path = self.write_config('''[scan]
ignore_paths = ["docs/**"]
max_file_bytes = 4096
max_files = 100
max_total_bytes = 8192
max_line_chars = 512
[rules]
disabled = ["RS004"]
severity = { RS003 = "critical" }
''')
        config = load_config(path, set(RULE_BY_ID), required=True)
        self.assertEqual(config.max_file_bytes, 4096)
        self.assertEqual(config.max_total_bytes, 8192)
        self.assertEqual(config.severity_overrides["RS003"], "critical")
        self.assertEqual(scan_content("DEBUG = True", "app.py", config), [])
        self.assertEqual(scan_content("DEBUG = True", "docs/example.py", config), [])

    def test_active_suppression_requires_reason_and_expiry(self):
        expiry = (date.today() + timedelta(days=2)).isoformat()
        path = self.write_config(f'''[[suppressions]]
rule = "RS004"
path = "src/*.py"
reason = "Development-only debug setting is covered by deployment policy"
expires = "{expiry}"
''')
        config = load_config(path, set(RULE_BY_ID), required=True)
        self.assertEqual(scan_content("DEBUG = True", "src/app.py", config), [])
        self.assertEqual(len(config.suppressions), 1)

    def test_expired_suppression_does_not_hide_finding(self):
        expiry = (date.today() - timedelta(days=1)).isoformat()
        path = self.write_config(f'''[[suppressions]]
rule = "RS004"
path = "src/*.py"
reason = "Temporary exception"
expires = "{expiry}"
''')
        config = load_config(path, set(RULE_BY_ID), required=True)
        self.assertTrue(config.warnings)
        self.assertEqual(len(scan_content("DEBUG = True", "src/app.py", config)), 1)

    def test_malformed_toml_is_rejected(self):
        path = self.write_config("[scan\nmax_files = 2")
        with self.assertRaises(ConfigurationError): load_config(path, set(RULE_BY_ID), required=True)

    def test_unknown_rule_is_rejected(self):
        path = self.write_config('[rules]\ndisabled = ["RS999"]\n')
        with self.assertRaises(ConfigurationError): load_config(path, set(RULE_BY_ID), required=True)

    def test_path_traversal_suppression_rejected(self):
        path = self.write_config('''[[suppressions]]
rule = "RS004"
path = "../*.py"
reason = "bad path"
expires = "2099-01-01"
''')
        with self.assertRaises(ConfigurationError): load_config(path, set(RULE_BY_ID), required=True)

    def test_config_size_limit(self):
        path = self.write_config("#" + "x" * 65536)
        with self.assertRaises(ConfigurationError): load_config(path, set(RULE_BY_ID), required=True)

if __name__ == "__main__": unittest.main()
