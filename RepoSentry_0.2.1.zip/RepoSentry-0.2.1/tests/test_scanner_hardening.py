import os
import tempfile
import unittest
from pathlib import Path
from reposentry.config import ScanConfig
from reposentry.rules import scan_path, scan_path_detailed

class ScannerHardeningTests(unittest.TestCase):
    def test_skips_binary_and_oversized_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "binary.py").write_bytes(b"DEBUG = True\x00\n")
            (root / "large.py").write_bytes(b"x" * 1025)
            findings = scan_path(root, config=ScanConfig(max_file_bytes=1024))
            self.assertEqual(findings, [])

    def test_invalid_utf8_is_skipped_with_diagnostic(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "bad.py").write_bytes(b"DEBUG = True\xff\n")
            findings, warnings = scan_path_detailed(root)
            self.assertEqual(findings, [])
            self.assertTrue(any("invalid UTF-8" in warning for warning in warnings))

    def test_oversized_file_is_reported_as_skipped(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "large.py").write_bytes(b"x" * 1025)
            findings, warnings = scan_path_detailed(root, config=ScanConfig(max_file_bytes=1024))
            self.assertEqual(findings, [])
            self.assertTrue(any("exceeds 1024-byte limit" in warning for warning in warnings))

    def test_symlink_file_is_skipped(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            target = root / "target.py"
            target.write_text("DEBUG = True\n", encoding="utf-8")
            link = root / "link.py"
            try:
                link.symlink_to(target)
            except (OSError, NotImplementedError):
                self.skipTest("symlink creation is not permitted on this platform")
            findings = scan_path(root)
            self.assertEqual({f.path for f in findings}, {"target.py"})

    def test_direct_symlink_target_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            target = root / "target.py"
            target.write_text("DEBUG = True\n", encoding="utf-8")
            link = root / "link.py"
            try:
                link.symlink_to(target)
            except (OSError, NotImplementedError):
                self.skipTest("symlink creation is not permitted on this platform")
            with self.assertRaises(OSError): scan_path(link)

    def test_total_byte_limit_fails_explicitly(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text("DEBUG = True\n", encoding="utf-8")
            with self.assertRaisesRegex(OSError, "Total scan byte limit exceeded"):
                scan_path(root, config=ScanConfig(max_total_bytes=4))

    def test_file_count_limit_fails_explicitly(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in ("a.py", "b.py"):
                (root / name).write_text("DEBUG = False\n", encoding="utf-8")
            with self.assertRaisesRegex(OSError, "file limit exceeded"):
                scan_path(root, config=ScanConfig(max_files=1))

    def test_env_variants_and_pem_files_are_scanned(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / ".env.local").write_text('API_KEY="sk_test_51H8j2K0d9m4Q7x6p3"\n', encoding="utf-8")
            (root / "private.pem").write_text("-----BEGIN PRIVATE KEY-----\n", encoding="utf-8")
            findings = scan_path(root)
            self.assertIn(("RS001", ".env.local"), {(f.rule_id, f.path) for f in findings})
            self.assertIn(("RS002", "private.pem"), {(f.rule_id, f.path) for f in findings})

    @unittest.skipIf(os.name == "nt", "Backslash is a path separator on Windows")
    def test_literal_backslash_in_posix_filename_is_not_reinterpreted(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            filename = "odd\\name.py"
            (root / filename).write_text("DEBUG = True\n", encoding="utf-8")
            findings = scan_path(root)
            self.assertIn(filename, {f.path for f in findings})

    def test_bom_and_crlf_are_supported(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_bytes(b"\xef\xbb\xbfDEBUG = True\r\n")
            findings = scan_path(root)
            self.assertIn("RS004", {f.rule_id for f in findings})

if __name__ == "__main__": unittest.main()
