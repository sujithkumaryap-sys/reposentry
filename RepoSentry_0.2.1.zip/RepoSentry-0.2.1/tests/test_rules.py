import unittest
from pathlib import Path
from reposentry.config import ScanConfig
from reposentry.rules import RULE_BY_ID, scan_content

FIXTURES = Path(__file__).parent / "fixtures" / "rules"

class RuleCorpusTests(unittest.TestCase):
    def test_each_rule_has_positive_and_negative_fixtures(self):
        for rule_id in RULE_BY_ID:
            with self.subTest(rule=rule_id):
                folder = FIXTURES / rule_id
                extension = {"RS002": "pem", "RS003": "js", "RS006": "tf"}.get(rule_id, "py")
                positive = folder / f"positive.{extension}"
                negative = folder / f"negative.{extension}"
                self.assertTrue(positive.is_file())
                self.assertTrue(negative.is_file())
                positive_findings = scan_content(positive.read_text(encoding="utf-8"), positive.name)
                negative_findings = scan_content(negative.read_text(encoding="utf-8"), negative.name)
                self.assertIn(rule_id, {f.rule_id for f in positive_findings}, f"positive fixture failed for {rule_id}")
                self.assertNotIn(rule_id, {f.rule_id for f in negative_findings}, f"negative fixture false positive for {rule_id}")

    def test_safe_documentation_examples_do_not_trigger_rules(self):
        path = FIXTURES / "documentation_examples.md"
        findings = scan_content(path.read_text(encoding="utf-8"), path.name)
        self.assertEqual(findings, [])

    def test_inline_comments_do_not_trigger_source_rules(self):
        text = "requests.get(url, verify=True)  # verify=False\nDEBUG = False  # DEBUG = True\nallow_origins = [\"https://app.example.com\"]  # allow_origins = [\"*\"]\n"
        self.assertEqual(scan_content(text, "app.py"), [])

    def test_comment_parsing_is_language_aware(self):
        # Python's // is floor division, not a line comment.
        self.assertIn("RS004", {f.rule_id for f in scan_content("value = total // 2; DEBUG = True\n", "app.py")})
        self.assertEqual(scan_content("const x = 1; // DEBUG = True\n", "app.js"), [])
        self.assertEqual(scan_content("select 1; -- DEBUG = True\n", "query.sql"), [])
        html = "<!-- start\nDEBUG = True\nend -->\nDEBUG = False\n"
        self.assertEqual(scan_content(html, "page.html"), [])

    def test_private_key_header_in_comment_is_ignored(self):
        self.assertNotIn("RS002", {f.rule_id for f in scan_content("# -----BEGIN PRIVATE KEY-----\n", "example.py")})

    def test_terraform_block_comment_does_not_trigger(self):
        text = "resource \"x\" \"y\" {\n  ingress {\n    /* cidr_blocks = [\"0.0.0.0/0\"] */\n    cidr_blocks = [\"10.0.0.0/8\"]\n  }\n}\n"
        self.assertNotIn("RS006", {f.rule_id for f in scan_content(text, "main.tf")})

    def test_rule_severity_override_is_applied(self):
        config = ScanConfig(severity_overrides={"RS004": "high"})
        findings = scan_content("DEBUG = True\n", "settings.py", config)
        self.assertEqual(findings[0].severity, "high")

    def test_disabled_rule_is_not_run(self):
        config = ScanConfig(disabled_rules={"RS004"})
        self.assertEqual(scan_content("DEBUG = True\n", "settings.py", config), [])

    def test_long_lines_are_skipped(self):
        config = ScanConfig(max_line_chars=256)
        self.assertEqual(scan_content("DEBUG = True " + ("x" * 300) + "\n", "settings.py", config), [])

    def test_repository_relative_posix_paths_are_preserved(self):
        findings = scan_content("DEBUG = True\r\n", "src/settings.py")
        self.assertEqual(findings[0].path, "src/settings.py")

    def test_terraform_comments_and_description_strings_do_not_trigger(self):
        text = '''resource "x" "y" {
  ingress {
    description = "0.0.0.0/0 is only documentation"
    # cidr_blocks = ["0.0.0.0/0"]
    cidr_blocks = ["10.0.0.0/8"]
  }
}
'''
        self.assertNotIn("RS006", {f.rule_id for f in scan_content(text, "main.tf")})

if __name__ == "__main__":
    unittest.main()
