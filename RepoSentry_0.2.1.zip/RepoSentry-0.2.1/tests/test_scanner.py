import json
import tempfile
import unittest
from pathlib import Path
from reposentry.rules import scan_path
from reposentry.reporters import json_report, sarif_report

class ScannerTests(unittest.TestCase):
    def test_detects_credential_without_leaking_value(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "settings.py").write_text('API_KEY = "super-secret-value-123"\n', encoding="utf-8")
            findings = scan_path(root)
            self.assertTrue(any(item.rule_id == "RS001" for item in findings))
            self.assertNotIn("super-secret-value-123", json_report(findings, str(root)))

    def test_detects_tls_verification_disabled(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "client.py").write_text("requests.get(url, verify=False)\n", encoding="utf-8")
            self.assertTrue(any(item.rule_id == "RS003" for item in scan_path(root)))

    def test_ignores_vendor_directories(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            vendor = root / "node_modules"
            vendor.mkdir()
            (vendor / "config.py").write_text('password = "not-a-real-secret-123"\n', encoding="utf-8")
            self.assertEqual(scan_path(root), [])

    def test_sarif_output_is_json(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text("DEBUG = True\n", encoding="utf-8")
            data = json.loads(sarif_report(scan_path(root), str(root)))
            self.assertEqual(data["version"], "2.1.0")
            self.assertTrue(data["runs"][0]["results"])

    def test_allow_rule(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text("DEBUG = True\n", encoding="utf-8")
            self.assertEqual(scan_path(root, allow_rules={"RS004"}), [])

    def test_multiline_terraform_ingress(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "main.tf").write_text('''resource "x" "y" {
  ingress {
    cidr_blocks = ["0.0.0.0/0"]
  }
}
''', encoding="utf-8")
            self.assertTrue(any(item.rule_id == "RS006" for item in scan_path(root)))

if __name__ == "__main__":
    unittest.main()
