# Safe documentation examples

```python
API_KEY = os.environ["API_KEY"]
requests.get(endpoint, verify=True)
DEBUG = False
allow_origins = ["https://app.example.com"]
```

```hcl
resource "aws_security_group" "web" {
  ingress {
    cidr_blocks = ["10.0.0.0/8"]
    description = "The string 0.0.0.0/0 is mentioned for explanation only"
  }
}
```

A public key header is not private key material:
`-----BEGIN PUBLIC KEY-----`
