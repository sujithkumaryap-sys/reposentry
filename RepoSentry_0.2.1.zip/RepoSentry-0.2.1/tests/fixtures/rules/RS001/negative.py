# API_KEY = "sk_test_51H8j2K0d9m4Q7x6p3"
API_KEY = "your_api_key_here"
API_KEY = os.environ["API_KEY"]
