// requests.get(endpoint, verify=False)
requests.get(endpoint, verify=True)
ssl_context.verify_mode = ssl.CERT_REQUIRED
