requests.get(endpoint, verify=False)
ssl_context.verify_mode = ssl.CERT_NONE
client = Thing(rejectUnauthorized: false)
