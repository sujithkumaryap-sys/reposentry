resource "aws_security_group" "web" {
  ingress {
    from_port = 443
    to_port = 443
    protocol = "tcp"
    cidr_blocks = ["10.0.0.0/8"]
    description = "0.0.0.0/0 is only an example in this string"
  }
}
# ingress { cidr_blocks = ["0.0.0.0/0"] }
