# allow_origins = ["*"]
allow_origins = ["https://app.example.com"]
