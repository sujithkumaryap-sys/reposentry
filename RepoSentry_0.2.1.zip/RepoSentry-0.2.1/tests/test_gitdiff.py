import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from reposentry.gitdiff import GitDiffError, scan_git_diff


def git(cwd, *args):
    return subprocess.run(["git", "-C", str(cwd), *args], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

class GitDiffTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        git(self.root, "init", "-q")
        git(self.root, "config", "user.email", "test@example.invalid")
        git(self.root, "config", "user.name", "RepoSentry Test")
        (self.root / "app.py").write_text("DEBUG = False\n", encoding="utf-8")
        (self.root / "deleted.py").write_text("DEBUG = True\n", encoding="utf-8")
        git(self.root, "add", ".")
        git(self.root, "commit", "-qm", "baseline")

    def test_staged_scans_index_snapshot(self):
        (self.root / "app.py").write_text('API_KEY = "sk_test_51H8j2K0d9m4Q7x6p3"\n', encoding="utf-8")
        git(self.root, "add", "app.py")
        findings, warnings = scan_git_diff(self.root, staged=True)
        self.assertFalse(warnings)
        self.assertIn("RS001", {f.rule_id for f in findings})

    def test_working_tree_scans_unstaged_and_untracked(self):
        (self.root / "app.py").write_text("requests.get(url, verify=False)\n", encoding="utf-8")
        (self.root / "new.py").write_text("DEBUG = True\n", encoding="utf-8")
        findings, _ = scan_git_diff(self.root, working_tree=True)
        self.assertIn(("RS003", "app.py"), {(f.rule_id, f.path) for f in findings})
        self.assertIn(("RS004", "new.py"), {(f.rule_id, f.path) for f in findings})

    def test_staged_snapshot_detects_secret_removed_from_worktree(self):
        (self.root / "app.py").write_text('API_KEY = "sk_test_51H8j2K0d9m4Q7x6p3"\n', encoding="utf-8")
        git(self.root, "add", "app.py")
        (self.root / "app.py").write_text("API_KEY = os.environ['API_KEY']\n", encoding="utf-8")
        findings, _ = scan_git_diff(self.root, staged=True)
        self.assertIn("RS001", {f.rule_id for f in findings})

    def test_deleted_files_are_ignored(self):
        (self.root / "deleted.py").unlink()
        git(self.root, "add", "deleted.py")
        findings, _ = scan_git_diff(self.root, staged=True)
        self.assertNotIn("deleted.py", {f.path for f in findings})

    def test_renamed_file_scans_destination(self):
        git(self.root, "mv", "app.py", "renamed.py")
        (self.root / "renamed.py").write_text("DEBUG = True\n", encoding="utf-8")
        git(self.root, "add", "renamed.py")
        findings, _ = scan_git_diff(self.root, staged=True)
        self.assertIn("renamed.py", {f.path for f in findings})

    def test_binary_changed_file_is_reported_as_skipped(self):
        binary = self.root / "blob.py"
        binary.write_bytes(b"DEBUG = True\x00\n")
        git(self.root, "add", "blob.py")
        findings, warnings = scan_git_diff(self.root, staged=True)
        self.assertNotIn("blob.py", {f.path for f in findings})
        self.assertTrue(any("binary" in warning for warning in warnings))

    def test_outside_git_directory_fails_cleanly(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(GitDiffError): scan_git_diff(Path(tmp), staged=True)

if __name__ == "__main__": unittest.main()
