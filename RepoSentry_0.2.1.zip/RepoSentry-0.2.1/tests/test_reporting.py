import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from reposentry.rules import scan_path
from reposentry.reporters import json_report, sarif_report, text_report
from reposentry.rules import scan_content

class ReportingTests(unittest.TestCase):
    def test_json_is_deterministic_and_redacted(self):
        findings = scan_content('API_KEY = "sk_test_51H8j2K0d9m4Q7x6p3"\n', "app.py")
        first = json_report(findings, ".")
        self.assertEqual(first, json_report(findings, "."))
        self.assertNotIn("sk_test_51H8j2K0d9m4Q7x6p3", first)
        self.assertEqual(json.loads(first)["finding_count"], 1)

    def test_sarif_has_valid_structure_and_stable_fingerprint(self):
        findings = scan_content("DEBUG = True\n", "src/app file.py")
        sarif = json.loads(sarif_report(findings, "."))
        self.assertEqual(sarif["version"], "2.1.0")
        run = sarif["runs"][0]
        self.assertIn("%SRCROOT%", run["originalUriBaseIds"])
        self.assertTrue(run["originalUriBaseIds"]["%SRCROOT%"]["uri"].startswith("file:"))
        self.assertEqual(run["tool"]["driver"]["rules"][0]["id"], "RS004")
        result = run["results"][0]
        self.assertEqual(result["locations"][0]["physicalLocation"]["region"]["startLine"], 1)
        self.assertIn("reposentry/v1", result["partialFingerprints"])
        artifact = result["locations"][0]["physicalLocation"]["artifactLocation"]
        self.assertEqual(artifact["uri"], "src/app%20file.py")
        self.assertEqual(artifact["uriBaseId"], "%SRCROOT%")

    @unittest.skipIf(os.name == "nt", "POSIX permits undecodable filename bytes")
    def test_non_utf8_filename_is_safely_encoded_in_sarif(self):
        with tempfile.TemporaryDirectory() as tmp:
            raw_path = os.fsencode(tmp) + b"/bad_\xff.py"
            fd = os.open(raw_path, os.O_WRONLY | os.O_CREAT, 0o600)
            with os.fdopen(fd, "wb") as stream:
                stream.write(b"DEBUG = True\n")
            findings = scan_path(Path(tmp))
            report = json.loads(sarif_report(findings, tmp))
            self.assertTrue(report["runs"][0]["results"])
            self.assertIn("%FF", report["runs"][0]["results"][0]["locations"][0]["physicalLocation"]["artifactLocation"]["uri"])

    def test_terminal_controls_are_escaped(self):
        findings = scan_content("DEBUG = True\n", "bad\n\x1b[31m.py")
        report = text_report(findings, "target\x1b[2J")
        self.assertNotIn("\x1b", report)
        self.assertIn("\\x1b", report)
        self.assertIn("\\x0a", report)

if __name__ == "__main__": unittest.main()
