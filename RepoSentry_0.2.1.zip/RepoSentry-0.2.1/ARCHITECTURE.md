# Architecture

## Data flow

```text
scan path / Git snapshot
        -> bounded discovery/read
        -> normalized UTF-8 text
        -> deterministic rule engine
        -> policy (enabled rules, severity overrides, ignores, expiring suppressions)
        -> normalized findings + stable fingerprints
        -> text / JSON / SARIF reporter
        -> severity threshold -> exit status
```

## Modules

- `cli.py`: argument parsing, configuration discovery, report output, and CI exit policy.
- `config.py`: bounded TOML loading, strict schema validation, rule policy, ignore globs, and expiring suppressions.
- `rules.py`: safe file traversal, bounded reads, six deterministic checks, Terraform brace parsing, normalization, and finding creation.
- `gitdiff.py`: Git metadata parsing, index blob reads, working-tree snapshots, path validation, and bounded Git subprocess calls.
- `models.py`: stable finding contract and severity order.
- `reporters.py`: terminal-safe text, deterministic JSON, and SARIF 2.1.0 output.
- `tests/fixtures/rules/`: positive, negative, and documentation fixtures for each rule.

## Important decisions

- **Local-first/no service:** repository content stays on the developer's machine.
- **Python 3.11+:** TOML is parsed with the standard-library `tomllib`, avoiding a runtime dependency.
- **No database/API:** the CLI is the core product; persistent state is not required for local scanning.
- **Bounded inputs:** config is capped at 64 KiB; scanned files have a configurable size limit (hard maximum 10 MiB); total bytes, file count, and line length are bounded; Git subprocesses time out.
- **No execution:** repository code is never imported or executed.
- **No shell:** Git commands use argument arrays; external diff is disabled, `core.fsmonitor` is disabled for the subprocess, and each command has a timeout.
- **Index correctness:** staged diff scans Git index blobs, not the mutable working copy.
- **Explainable heuristics:** rules have stable IDs and generic messages. They do not return matched secret values.
- **No automatic fixes:** findings recommend remediation without mutating source code.
- **Stable output:** deterministic sorting, JSON key order, normalized paths, and fingerprints.

## Rule-engine safety

Credential and common configuration rules operate on bounded lines. Terraform ingress detection uses a single-pass brace walk outside strings/comments and then checks recognized CIDR attributes, rather than a broad multiline regex over arbitrary text. This reduces false positives from descriptions and avoids pathological nested-block regex behavior.

## Git diff semantics

Git diff scans complete snapshots for changed destination paths so multiline rules work. Staged snapshots come from index blob object IDs and are size-checked before reading. Working-tree snapshots are resolved and constrained to the repository root. Deleted paths are skipped; renamed paths are scanned at the destination; binary, symlink, oversized, and invalid-UTF-8 files are skipped. Default mode scans staged and working-tree snapshots, then deduplicates equivalent findings.

## Future architecture

Prioritize precision measurements, language-aware parsing, scan diagnostics for skipped files, and pre-commit/CI adoption before adding a server or dashboard. For broader coverage, prefer adapters to mature dependency and SAST tools over reimplementing those engines.
