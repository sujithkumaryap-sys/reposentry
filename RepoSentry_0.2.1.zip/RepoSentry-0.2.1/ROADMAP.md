# Roadmap

## v0.1.0 — Initial MVP
- [x] Local recursive scanner
- [x] Six heuristic rules
- [x] Text, JSON, SARIF output
- [x] Severity-based exit behavior

## v0.2.0 — Reliability and developer workflow
- [x] Positive/negative rule fixtures and documentation examples
- [x] Bounded TOML configuration and strict validation
- [x] Rule enable/disable and severity overrides
- [x] Required suppression reason and expiry
- [x] Improved multiline Terraform block matching
- [x] Deterministic JSON and SARIF metadata/fingerprints
- [x] Cross-platform CI matrix
- [x] Packaging and dependency audit gates
- [x] Git staged/working-tree/untracked scanning
- [x] Optional pre-commit integration
- [x] Threat-model documentation
- [x] Emit warnings for skipped oversized, binary, invalid-encoding, symlink, and overlong-line inputs where detectable
- [ ] Validate SARIF against the target platform/schema in CI
- [ ] Measure precision/recall on a labeled fixture corpus

## v0.3 — Trust and integration
- [ ] Add baseline/suppression reporting and expiry enforcement in CI
- [ ] Add rule-level fixture metadata and benchmark harness
- [ ] Add more language-aware parsing only where evidence shows value
- [ ] Optional dependency-audit adapter (delegate to mature tools)
- [ ] Optional Semgrep/Trivy adapters
- [ ] Reproducible release artifacts and signed provenance

## v1.0 release criteria
- [ ] Threat model reviewed by an external reviewer
- [ ] Stable rule specification and semantic versioning
- [ ] Labeled corpus with measured precision/recall
- [ ] Full OS/Python CI matrix and release process
- [ ] SARIF compatibility validated against supported integrations
- [ ] Documented policy for rule changes and false-positive reports
- [ ] Clear limitations and user feedback
