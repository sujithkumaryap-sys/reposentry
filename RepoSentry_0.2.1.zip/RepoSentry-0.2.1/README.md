# RepoSentry

**A local-first repository security gate for developers.** RepoSentry checks selected source/configuration patterns, emits sanitized findings, and can fail CI or a pre-commit hook at a configured severity threshold.

> **Version 0.2.0 — alpha.** This is a heuristic scanner, not a replacement for dedicated secret scanning, SAST, dependency auditing, or cloud-security tools. A clean scan is not proof of security.

## Why RepoSentry?

The goal is to make a small, transparent set of security checks easy to run locally and enforce in CI—without an account, hosted service, paid API, or runtime dependencies.

## Requirements

- Python 3.11+ (uses the standard-library `tomllib` parser)
- Git is required only for `reposentry diff`

## Install

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
# macOS/Linux
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install .
```

For development, use `python -m pip install -e .`.

## Commands

```bash
# Scan the current directory
reposentry scan .

# Write JSON or SARIF (SARIF is JSON)
reposentry scan . --format json --output reports/reposentry.json
reposentry scan . --format sarif --output reports/reposentry.sarif

# Fail if medium or higher findings exist
reposentry scan . --fail-on medium

# Scan staged/index snapshots only
reposentry diff --staged

# Scan unstaged tracked changes and untracked files
reposentry diff --working-tree

# Scan staged + working-tree snapshots (default)
reposentry diff

# Use a particular configuration or explicitly disable configuration discovery
reposentry scan . --config .reposentry.toml
reposentry scan . --no-config
```

### Exit codes

- `0`: scan completed and no finding met `--fail-on`.
- `1`: one or more findings met `--fail-on`.
- `2`: configuration, Git, path, or report-output error.

`--fail-on` defaults to `high`. It controls the exit status; it does not remove lower-severity findings from reports.

## Current rules

| ID | Check | Default severity | Notes |
|---|---|---:|---|
| RS001 | Credential-like assignment | High | Redacts values; ignores common placeholders and environment lookups |
| RS002 | Private-key PEM header | Critical | Flags the header; does not validate cryptographic material |
| RS003 | TLS verification disabled | High | Selected Python/JavaScript-style patterns |
| RS004 | Debug mode enabled | Medium | Selected common configuration patterns |
| RS005 | Wildcard CORS | Medium | Selected common header/framework patterns |
| RS006 | Public Terraform ingress CIDR | High | Checks `cidr_blocks`, `ipv6_cidr_blocks`, and `source_ranges` inside `ingress` blocks |

Rules are deterministic heuristics. They can miss variants or flag unusual but harmless code. Review findings before changing software.

## Configuration

Copy `.reposentry.example.toml` to `.reposentry.toml` and edit it. RepoSentry discovers `.reposentry.toml` at the scan root or Git repository root. An explicit `--config` path must exist. Use `--no-config` to disable discovery.

```toml
[scan]
ignore_paths = ["docs/generated/**", "**/fixtures/**"]
max_file_bytes = 1048576
max_files = 10000
max_total_bytes = 268435456
max_line_chars = 20000

[rules]
# Omit enabled to enable all known rules.
# enabled = ["RS001", "RS002", "RS003", "RS004", "RS005", "RS006"]
disabled = ["RS004"]
severity = { RS003 = "critical" }

[[suppressions]]
rule = "RS004"
path = "src/dev_settings.py"
reason = "Development-only debug setting; production deployment disables it"
expires = "2027-01-31"
```

Configuration is strict: unknown keys/rule IDs, invalid severity names, malformed TOML, invalid limits, and malformed suppressions are errors. Configuration is capped at 64 KiB. Per-file size, total scanned bytes, file count, and line length limits are bounded to prevent accidental resource exhaustion. `ignore_paths` and suppression paths use repository-relative POSIX-style globs.

A suppression **must** specify a rule ID, path/glob, non-empty reason, and `YYYY-MM-DD` expiry. Expired suppressions do not apply and emit a warning. A suppression is not a substitute for fixing a finding.

Command-line `--allow-rule` and `--allow-path` are temporary per-invocation overrides; prefer documented expiring suppressions for durable exceptions.

## Git diff scanning behavior

`reposentry diff` is Git-aware and scans the complete changed-file snapshot rather than only added lines. This is intentional so multiline checks (such as Terraform ingress) still work.

- `--staged`: reads blobs from the Git index, not the working-tree copy.
- `--working-tree`: scans unstaged tracked changes and untracked, non-ignored files from disk.
- no mode flag: scans both staged snapshots and working-tree snapshots.
- deleted files are ignored; renames scan the destination path.
- binary files, symlinks, files above `scan.max_file_bytes`, and files with invalid UTF-8 are skipped with warnings where RepoSentry can identify the skip.
- generated/vendor directories and paths excluded by configuration are not scanned.
- a changed-file limit is enforced using `scan.max_files`.
- Git commands are invoked without a shell, external diff is disabled, and commands have a timeout.

Because full changed files are scanned, a pre-existing issue in a modified file can appear in a diff scan. This is a deliberate MVP trade-off for multiline accuracy. Findings are deduplicated in output. Review staged content carefully before committing.

## Pre-commit integration

Install pre-commit with `python -m pip install pre-commit`, install RepoSentry into the same environment, and add this to your `.pre-commit-config.yaml`:

```yaml
repos:
  - repo: local
    hooks:
      - id: reposentry
        name: RepoSentry staged security scan
        entry: reposentry diff --staged --fail-on high
        language: system
        pass_filenames: false
        always_run: true
```

Then run `pre-commit install`. The staged scan reads index blobs, so it checks what is about to be committed rather than blindly scanning the unstaged working copy. It can be bypassed by a user; enforce the same checks in CI.

The repository also includes `.pre-commit-hooks.yaml` for consumers who publish/fork the project and want to expose it as a remote hook. Replace the example repository URL in consumer configuration with the real published repository URL.

## JSON and SARIF

- JSON uses a versioned wrapper and deterministic key ordering.
- SARIF output declares version 2.1.0, includes stable rule IDs, source locations, severity, and fingerprints.
- Paths use forward slashes and URI escaping in SARIF.
- Findings never include the matched credential value.

SARIF is designed for static-analysis result interchange. Validate the generated file against the platform-specific subset before relying on upload integration.

## CI

The GitHub Actions workflow runs the test matrix on Linux, Windows, and macOS for Python 3.11–3.13. A quality job validates compilation, builds a wheel, and runs a dependency audit. CI actions are pinned to immutable commit SHAs.

## Security and privacy

- Scans are local; no code or findings are sent to a RepoSentry service.
- Scanned files are never executed.
- File reads, config size, line length, file count, and Git subprocess time are bounded.
- Symlinks are skipped; files outside the scan root are not followed.
- Terminal control characters in paths are escaped.
- Finding text is generic and does not echo matched values.

See [SECURITY.md](SECURITY.md) for the threat model and limitations.

## Development and testing

```bash
python -m unittest discover -s tests -v
python -m compileall -q reposentry tests
python -m reposentry scan . --no-config
```

See [ARCHITECTURE.md](ARCHITECTURE.md), [TESTING.md](TESTING.md), [SECURITY.md](SECURITY.md), [ROADMAP.md](ROADMAP.md), [CHANGELOG.md](CHANGELOG.md), and [PROJECT_STATE.yaml](PROJECT_STATE.yaml).
