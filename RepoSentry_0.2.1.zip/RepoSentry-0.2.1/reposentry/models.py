from dataclasses import asdict, dataclass
import hashlib
import json

SEVERITIES = ("info", "low", "medium", "high", "critical")
SEVERITY_RANK = {name: index for index, name in enumerate(SEVERITIES)}

@dataclass(frozen=True)
class Finding:
    rule_id: str
    title: str
    severity: str
    message: str
    path: str
    line: int
    recommendation: str
    fingerprint: str = ""

    def __post_init__(self):
        if not self.fingerprint:
            # Location-independent fingerprint is stable across line shifts.
            material = "\0".join((self.rule_id, self.path, self.title))
            object.__setattr__(self, "fingerprint", hashlib.sha256(material.encode("utf-8", "surrogateescape")).hexdigest())

    def to_dict(self):
        return asdict(self)
