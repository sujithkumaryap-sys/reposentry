"""Git-aware scanning of staged, unstaged, and untracked file snapshots."""
from pathlib import Path, PurePosixPath
from fnmatch import fnmatchcase
import subprocess
from reposentry.config import ScanConfig
from reposentry.rules import is_candidate, scan_content

class GitDiffError(RuntimeError):
    pass

class GitRunner:
    def __init__(self, cwd: Path):
        self.cwd = Path(cwd).resolve()
        self.env = {"GIT_OPTIONAL_LOCKS": "0", "GIT_TERMINAL_PROMPT": "0"}

    def run(self, *args: str, check: bool = True) -> bytes:
        try:
            result = subprocess.run(["git", "-C", str(self.cwd), "-c", "core.fsmonitor=false", *args], stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, check=False, timeout=30,
                                    env={**__import__("os").environ, **self.env})
        except FileNotFoundError as exc:
            raise GitDiffError("Git executable was not found on PATH") from exc
        except subprocess.TimeoutExpired as exc:
            raise GitDiffError("Git command exceeded the 30-second timeout") from exc
        if check and result.returncode:
            message = result.stderr.decode("utf-8", "replace").strip()
            raise GitDiffError(message or f"git {' '.join(args)} failed with exit code {result.returncode}")
        return result.stdout

def _changed_paths(raw: bytes) -> list[tuple[str, str]]:
    """Parse `git diff --name-status -z`; return (status, destination path)."""
    fields = raw.split(b"\0")
    if fields and fields[-1] == b"": fields.pop()
    out, i = [], 0
    while i < len(fields):
        status = fields[i].decode("ascii", "replace")
        i += 1
        if status.startswith(("R", "C")):
            if i + 1 >= len(fields): raise GitDiffError("Malformed Git rename/copy status output")
            _old, new = fields[i], fields[i + 1]
            i += 2
            out.append((status[0], new.decode("utf-8", "strict")))
        else:
            if i >= len(fields): raise GitDiffError("Malformed Git name-status output")
            path = fields[i]
            i += 1
            out.append((status[:1], path.decode("utf-8", "strict")))
    return out

def _valid_repo_relative(raw_path: str) -> str | None:
    # Git's -z paths use '/' separators; preserve literal backslashes in POSIX filenames.
    path = raw_path
    pure = PurePosixPath(path)
    if pure.is_absolute() or ".." in pure.parts or not path or path.startswith("/"):
        return None
    return path

def _index_blob(git: GitRunner, path: str, max_bytes: int) -> tuple[str | None, str | None]:
    # The path is an argument after `--`, never shell-interpolated.
    entries = git.run("ls-files", "--stage", "-z", "--", ":(literal)" + path).split(b"\0")
    candidates = []
    saw_entry = False
    for entry in entries:
        if not entry: continue
        saw_entry = True
        try:
            metadata, _name = entry.split(b"\t", 1)
            mode, oid, stage = metadata.decode("ascii").split()
        except (ValueError, UnicodeDecodeError):
            continue
        if stage == "0": candidates.append((mode, oid))
    if not candidates:
        if saw_entry:
            raise GitDiffError(f"Unmerged index entries for {path}; resolve the conflict before scanning staged content")
        return None, None
    if len(candidates) != 1:
        raise GitDiffError(f"Unmerged index entries for {path}; resolve the conflict before scanning staged content")
    mode, oid = candidates[0]
    if mode not in {"100644", "100755"}:
        return None, "symlink/submodule/special index entry"
    size_raw = git.run("cat-file", "-s", oid).strip()
    try: size = int(size_raw)
    except ValueError as exc: raise GitDiffError(f"Invalid Git object size for {path}") from exc
    if size > max_bytes: return None, f"blob exceeds {max_bytes}-byte limit"
    content = git.run("cat-file", "blob", oid)
    if len(content) > max_bytes: return None, f"blob exceeds {max_bytes}-byte limit"
    if b"\x00" in content: return None, "binary blob"
    try: text = content.decode("utf-8-sig", "strict")
    except UnicodeError: return None, "invalid UTF-8 blob"
    return text, None

def _working_text(root: Path, rel: str, max_bytes: int) -> tuple[str | None, str | None]:
    candidate = root.joinpath(*PurePosixPath(rel).parts)
    try:
        if candidate.is_symlink(): return None, "symbolic link"
        resolved = candidate.resolve(strict=True)
        if not resolved.is_relative_to(root.resolve()): return None, "path resolves outside repository root"
        if not resolved.is_file(): return None, "not a regular file"
        if resolved.stat().st_size > max_bytes: return None, f"file exceeds {max_bytes}-byte limit"
        with resolved.open("rb") as stream:
            raw = stream.read(max_bytes + 1)
        if len(raw) > max_bytes: return None, f"file exceeds {max_bytes}-byte limit while reading"
        if b"\x00" in raw: return None, "binary content"
        return raw.decode("utf-8-sig", "strict"), None
    except UnicodeError:
        return None, "invalid UTF-8 encoding"
    except (OSError, RuntimeError) as exc:
        return None, f"read failed ({type(exc).__name__})"

def scan_git_diff(target: Path, config: ScanConfig | None = None, staged: bool = False,
                  working_tree: bool = False) -> tuple[list, list[str]]:
    """Scan added/modified paths' current snapshots. Default scans index and worktree.

    Findings are from the complete changed-file snapshot (not only added lines), which
    supports multiline rules. Staged mode reads index blobs; worktree mode reads files.
    Deleted files are ignored; renames scan the destination; untracked files belong to
    worktree mode. Binary, symlink, oversized, and unsupported-encoding files are skipped.
    """
    config = config or ScanConfig()
    root_runner = GitRunner(target)
    try:
        root_text = root_runner.run("rev-parse", "--show-toplevel").decode("utf-8", "strict").strip()
    except UnicodeError as exc:
        raise GitDiffError("Git returned an invalid repository root encoding") from exc
    root = Path(root_text).resolve()
    git = GitRunner(root)
    if not staged and not working_tree:
        staged = working_tree = True
    paths: list[tuple[str, str]] = []
    try:
        if staged:
            paths.extend(("staged", p) for status, p in _changed_paths(git.run("diff", "--cached", "--name-status", "-z", "--find-renames", "--no-ext-diff", "--")) if status != "D")
        if working_tree:
            paths.extend(("worktree", p) for status, p in _changed_paths(git.run("diff", "--name-status", "-z", "--find-renames", "--no-ext-diff", "--")) if status != "D")
            untracked = git.run("ls-files", "--others", "--exclude-standard", "-z", "--")
            for item in untracked.split(b"\0"):
                if item:
                    paths.append(("worktree", item.decode("utf-8", "strict")))
    except UnicodeError as exc:
        raise GitDiffError("A changed Git path is not valid UTF-8; RepoSentry skips non-UTF-8 paths") from exc
    eligible_paths = set()
    for source, raw_path in paths:
        relative = _valid_repo_relative(raw_path)
        if relative is None or not is_candidate(Path(relative)):
            continue
        if any(fnmatchcase(relative, pattern.replace("\\", "/")) for pattern in config.ignore_paths):
            continue
        eligible_paths.add((source, relative))
    if len(eligible_paths) > config.max_files:
        raise GitDiffError(f"Changed-file limit exceeded ({config.max_files}); narrow the changes or configure scan.max_files")
    findings, warnings = [], []
    bytes_scanned = 0
    seen = set()
    for source, raw_path in paths:
        rel = _valid_repo_relative(raw_path)
        if rel is None:
            warnings.append("Skipped unsafe/non-relative Git path")
            continue
        if (source, rel) in seen or not is_candidate(Path(rel)):
            continue
        seen.add((source, rel))
        if any(fnmatchcase(rel, p.replace("\\", "/")) for p in config.ignore_paths):
            continue
        if source == "staged":
            text, skip_reason = _index_blob(git, rel, config.max_file_bytes)
        else:
            text, skip_reason = _working_text(root, rel, config.max_file_bytes)
        if text is None:
            if skip_reason:
                warnings.append(f"Skipped {rel} ({source}): {skip_reason}")
            continue
        bytes_scanned += len(text.encode("utf-8", "surrogateescape"))
        if bytes_scanned > config.max_total_bytes:
            raise GitDiffError(f"Total diff scan byte limit exceeded ({config.max_total_bytes}); narrow the changes or configure scan.max_total_bytes")
        long_lines = sum(1 for line in text.splitlines() if len(line) > config.max_line_chars)
        if long_lines:
            warnings.append(f"Skipped {long_lines} overlong line(s) in {rel} ({source}; limit {config.max_line_chars})")
        findings.extend(scan_content(text, rel, config))
    unique = {(f.rule_id, f.path, f.line): f for f in findings}
    return sorted(unique.values(), key=lambda f: (f.path.casefold(), f.line, f.rule_id)), sorted(set(warnings))
