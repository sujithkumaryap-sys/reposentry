"""Command-line interface for RepoSentry."""
import argparse
import sys
from pathlib import Path
from reposentry import __version__
from reposentry.config import CONFIG_NAME, ConfigurationError, load_config
from reposentry.gitdiff import GitDiffError, GitRunner, scan_git_diff
from reposentry.models import SEVERITY_RANK
from reposentry.reporters import json_report, sarif_report, text_report, safe_terminal
from reposentry.rules import RULE_BY_ID, scan_path_detailed

def _add_report_options(parser):
    parser.add_argument("--config", help="Path to TOML configuration (default: .reposentry.toml at target/repository root)")
    parser.add_argument("--no-config", action="store_true", help="Ignore automatic configuration discovery")
    parser.add_argument("--format", choices=("text", "json", "sarif"), default="text")
    parser.add_argument("--output", help="Write report to a file instead of stdout")
    parser.add_argument("--fail-on", choices=tuple(SEVERITY_RANK), default="high",
                        help="Exit 1 when a finding meets or exceeds this severity (default: high)")

def build_parser():
    parser = argparse.ArgumentParser(prog="reposentry", description="Local-first repository security gate")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)
    scan = sub.add_parser("scan", help="Scan a file or repository directory")
    scan.add_argument("target", nargs="?", default=".")
    _add_report_options(scan)
    scan.add_argument("--allow-rule", action="append", default=[], help="Suppress a rule ID for this invocation (repeatable)")
    scan.add_argument("--allow-path", action="append", default=[], help="Skip an exact repository-relative path (repeatable)")

    diff = sub.add_parser("diff", help="Scan changed Git file snapshots")
    diff.add_argument("target", nargs="?", default=".", help="Repository directory or subdirectory")
    mode = diff.add_mutually_exclusive_group()
    mode.add_argument("--staged", action="store_true", help="Scan staged/index changes only")
    mode.add_argument("--working-tree", action="store_true", help="Scan unstaged and untracked working-tree changes only")
    _add_report_options(diff)
    return parser

def _config_path(args, target: Path) -> Path | None:
    if args.no_config:
        if args.config:
            raise ConfigurationError("--config and --no-config cannot be used together")
        return None
    if args.config:
        return Path(args.config)
    if target.is_symlink():
        raise OSError("Refusing to follow a symbolic-link scan target")
    base = target.resolve()
    if base.is_file(): base = base.parent
    # For subdirectories, prefer the repository root if Git can identify one.
    try:
        from reposentry.gitdiff import GitRunner
        root = GitRunner(base).run("rev-parse", "--show-toplevel").decode("utf-8", "strict").strip()
        base = Path(root)
    except (GitDiffError, UnicodeError):
        pass
    candidate = base / CONFIG_NAME
    return candidate if candidate.exists() else None

def _render(args, findings, target_label, source_root=None):
    if args.format == "sarif":
        return sarif_report(findings, target_label, source_root=source_root)
    return {"text": text_report, "json": json_report}[args.format](findings, target_label)

def _write_report(args, rendered):
    if not args.output:
        sys.stdout.write(rendered if rendered.endswith("\n") else rendered + "\n")
        return
    try:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(rendered if rendered.endswith("\n") else rendered + "\n", encoding="utf-8", newline="\n")
    except OSError as exc:
        raise OSError(f"Cannot write report: {exc}") from exc

def main(argv=None):
    args = build_parser().parse_args(argv)
    target = Path(args.target)
    try:
        config_path = _config_path(args, target)
        config = load_config(config_path, set(RULE_BY_ID), required=bool(args.config))
        if args.command == "scan":
            unknown_allow = set(args.allow_rule) - set(RULE_BY_ID)
            if unknown_allow:
                raise ConfigurationError(f"Unknown rule ID(s) in --allow-rule: {', '.join(sorted(unknown_allow))}")
        for warning in config.warnings:
            print(f"RepoSentry warning: {safe_terminal(warning)}", file=sys.stderr)
        if args.command == "scan":
            source_root = target.resolve()
            if source_root.is_file():
                source_root = source_root.parent
            findings, warnings = scan_path_detailed(target, allow_rules=set(args.allow_rule), allow_paths=set(args.allow_path), config=config)
            for warning in warnings:
                print(f"RepoSentry warning: {safe_terminal(warning)}", file=sys.stderr)
            label = str(target.resolve())
        elif args.command == "diff":
            repo_root = GitRunner(target).run("rev-parse", "--show-toplevel").decode("utf-8", "strict").strip()
            source_root = Path(repo_root).resolve()
            findings, warnings = scan_git_diff(target, config, staged=args.staged, working_tree=args.working_tree)
            for warning in warnings:
                print(f"RepoSentry warning: {safe_terminal(warning)}", file=sys.stderr)
            label = f"git diff ({'staged' if args.staged else 'working-tree' if args.working_tree else 'staged + working-tree'})"
        else:
            return 2
        _write_report(args, _render(args, findings, label, source_root=source_root))
    except (ConfigurationError, GitDiffError, OSError, ValueError) as exc:
        print(f"RepoSentry error: {safe_terminal(str(exc))}", file=sys.stderr)
        return 2
    threshold = SEVERITY_RANK[args.fail_on]
    return 1 if any(SEVERITY_RANK[item.severity] >= threshold for item in findings) else 0

if __name__ == "__main__":
    raise SystemExit(main())
