"""Deterministic, sanitized report serializers."""
import json
from pathlib import Path
from collections import Counter
from urllib.parse import quote_from_bytes
import unicodedata
from reposentry import __version__
from reposentry.models import SEVERITIES

def safe_terminal(value: str) -> str:
    # Escape terminal controls/newlines in untrusted paths and target labels.
    return "".join(ch if not unicodedata.category(ch).startswith("C") else (f"\\x{ord(ch):02x}" if ord(ch) < 256 else f"\\u{ord(ch):04x}") for ch in str(value))

def text_report(findings, target):
    lines = [f"RepoSentry {__version__} — scan target: {safe_terminal(target)}"]
    if not findings:
        lines.append("No findings detected by the enabled heuristic rules.")
    for finding in findings:
        path = safe_terminal(finding.path)
        lines.append(f"{finding.severity.upper():8} {finding.rule_id}  {path}:{finding.line}  {safe_terminal(finding.title)}")
        lines.append(f"         {safe_terminal(finding.message)}")
        lines.append(f"         Fix: {safe_terminal(finding.recommendation)}")
    counts = Counter(item.severity for item in findings)
    summary = ", ".join(f"{level}={counts[level]}" for level in reversed(SEVERITIES) if counts[level])
    lines.append(f"Summary: {len(findings)} finding(s)" + (f" ({summary})" if summary else ""))
    return "\n".join(lines)

def json_report(findings, target):
    return json.dumps({
        "schema_version": "1.0",
        "tool": {"name": "RepoSentry", "version": __version__},
        "target": str(target).replace("\\", "/"),
        "finding_count": len(findings),
        "findings": [item.to_dict() for item in findings],
    }, ensure_ascii=True, sort_keys=True, indent=2) + "\n"

def _sarif_level(severity):
    if severity in ("critical", "high"):
        return "error"
    if severity in ("medium", "low"):
        return "warning"
    return "note"

def sarif_report(findings, target, source_root=None):
    # SARIF relative artifact URIs need an explicit base. Keep findings portable
    # within the analyzed source tree while giving consumers an unambiguous root.
    root = Path(source_root if source_root is not None else target).resolve()
    if root.is_file():
        root = root.parent
    root_uri = root.as_uri()
    if not root_uri.endswith('/'):
        root_uri += '/'
    rules, results = {}, []
    for finding in findings:
        rules.setdefault(finding.rule_id, {
            "id": finding.rule_id,
            "name": finding.title,
            "shortDescription": {"text": finding.title},
            "fullDescription": {"text": finding.message},
            "help": {"text": finding.recommendation},
            "defaultConfiguration": {"level": _sarif_level(finding.severity)},
            "properties": {"tags": ["security", "reposentry"], "precision": "medium"},
        })
        results.append({
            "ruleId": finding.rule_id,
            "ruleIndex": list(rules).index(finding.rule_id),
            "level": _sarif_level(finding.severity),
            "message": {"text": finding.message},
            "locations": [{"physicalLocation": {
                "artifactLocation": {"uri": quote_from_bytes(finding.path.encode("utf-8", "surrogateescape"), safe="/-._~"), "uriBaseId": "%SRCROOT%"},
                "region": {"startLine": finding.line},
            }}],
            "partialFingerprints": {"reposentry/v1": finding.fingerprint},
            "properties": {"severity": finding.severity},
        })
    return json.dumps({
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [{"tool": {"driver": {
            "name": "RepoSentry", "version": __version__,
            "rules": list(rules.values()),
        }}, "originalUriBaseIds": {"%SRCROOT%": {"uri": root_uri}}, "results": results}],
    }, ensure_ascii=True, sort_keys=True, indent=2) + "\n"
