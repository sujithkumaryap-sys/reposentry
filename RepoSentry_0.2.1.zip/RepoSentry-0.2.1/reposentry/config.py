"""Validated TOML configuration and expiring suppressions."""
from dataclasses import dataclass, field
from datetime import date
from fnmatch import fnmatchcase
from pathlib import Path, PurePosixPath
import tomllib
import re

CONFIG_NAME = ".reposentry.toml"
MAX_CONFIG_BYTES = 64 * 1024
MAX_FILE_BYTES_HARD_LIMIT = 10 * 1024 * 1024
MAX_FILES_HARD_LIMIT = 100_000
MAX_TOTAL_BYTES_HARD_LIMIT = 1_073_741_824
MAX_LINE_CHARS_HARD_LIMIT = 100_000

class ConfigurationError(ValueError):
    pass

@dataclass(frozen=True)
class Suppression:
    rule: str
    path: str
    reason: str
    expires: date

    def matches(self, rule_id: str, relative_path: str, today: date | None = None) -> bool:
        today = today or date.today()
        return (self.rule == rule_id and self.expires >= today and
                fnmatchcase(relative_path.replace("\\", "/"), self.path))

@dataclass
class ScanConfig:
    enabled_rules: set[str] | None = None
    disabled_rules: set[str] = field(default_factory=set)
    severity_overrides: dict[str, str] = field(default_factory=dict)
    ignore_paths: list[str] = field(default_factory=list)
    max_file_bytes: int = 1_048_576
    max_files: int = 10_000
    max_total_bytes: int = 256 * 1024 * 1024
    max_line_chars: int = 20_000
    suppressions: list[Suppression] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def rule_enabled(self, rule_id: str) -> bool:
        return (self.enabled_rules is None or rule_id in self.enabled_rules) and rule_id not in self.disabled_rules

    def suppression_for(self, rule_id: str, path: str) -> Suppression | None:
        for item in self.suppressions:
            if item.matches(rule_id, path):
                return item
        return None

def _string_list(value, label):
    if not isinstance(value, list) or any(not isinstance(x, str) or not x.strip() for x in value):
        raise ConfigurationError(f"{label} must be an array of non-empty strings")
    return value

def load_config(path: Path | None, known_rules: set[str], required: bool = False) -> ScanConfig:
    config = ScanConfig()
    if path is None:
        return config
    path = Path(path)
    if not path.exists():
        if required:
            raise ConfigurationError(f"Configuration file not found: {path}")
        return config
    try:
        with path.open("rb") as stream:
            raw = stream.read(MAX_CONFIG_BYTES + 1)
        if len(raw) > MAX_CONFIG_BYTES:
            raise ConfigurationError(f"Configuration exceeds {MAX_CONFIG_BYTES} bytes")
        data = tomllib.loads(raw.decode("utf-8"))
    except ConfigurationError:
        raise
    except (OSError, UnicodeError, tomllib.TOMLDecodeError) as exc:
        raise ConfigurationError(f"Cannot read configuration: {exc}") from exc

    if not isinstance(data, dict):
        raise ConfigurationError("Configuration root must be a TOML table")
    allowed_top = {"scan", "rules", "suppressions"}
    unknown_top = set(data) - allowed_top
    if unknown_top:
        raise ConfigurationError(f"Unknown top-level key(s): {', '.join(sorted(unknown_top))}")
    scan = data.get("scan", {})
    rules = data.get("rules", {})
    if not isinstance(scan, dict) or not isinstance(rules, dict):
        raise ConfigurationError("[scan] and [rules] must be tables")
    unknown_scan = set(scan) - {"ignore_paths", "max_file_bytes", "max_files", "max_total_bytes", "max_line_chars"}
    unknown_rules = set(rules) - {"enabled", "disabled", "severity"}
    if unknown_scan or unknown_rules:
        unknown = sorted(unknown_scan | unknown_rules)
        raise ConfigurationError(f"Unknown configuration key(s): {', '.join(unknown)}")

    if "enabled" in rules:
        config.enabled_rules = set(_string_list(rules["enabled"], "rules.enabled"))
    if "disabled" in rules:
        config.disabled_rules = set(_string_list(rules["disabled"], "rules.disabled"))
    for rule_id in (config.enabled_rules or set()) | config.disabled_rules:
        if rule_id not in known_rules:
            raise ConfigurationError(f"Unknown rule ID: {rule_id}")
    if config.enabled_rules is not None and config.enabled_rules & config.disabled_rules:
        conflict = ", ".join(sorted(config.enabled_rules & config.disabled_rules))
        raise ConfigurationError(f"Rule IDs cannot be both enabled and disabled: {conflict}")

    severity = rules.get("severity", {})
    if not isinstance(severity, dict):
        raise ConfigurationError("rules.severity must be a table of rule IDs to severity names")
    from reposentry.models import SEVERITIES
    for rule_id, level in severity.items():
        if rule_id not in known_rules:
            raise ConfigurationError(f"Unknown rule ID in rules.severity: {rule_id}")
        if not isinstance(level, str) or level not in SEVERITIES:
            raise ConfigurationError(f"Invalid severity for {rule_id}: {level!r}")
        config.severity_overrides[rule_id] = level

    config.ignore_paths = _string_list(scan.get("ignore_paths", []), "scan.ignore_paths")
    for key, minimum, maximum in (("max_file_bytes", 1, MAX_FILE_BYTES_HARD_LIMIT),
                                  ("max_files", 1, MAX_FILES_HARD_LIMIT),
                                  ("max_total_bytes", 1, MAX_TOTAL_BYTES_HARD_LIMIT),
                                  ("max_line_chars", 256, MAX_LINE_CHARS_HARD_LIMIT)):
        value = scan.get(key, getattr(config, key))
        if not isinstance(value, int) or isinstance(value, bool) or not minimum <= value <= maximum:
            raise ConfigurationError(f"scan.{key} must be an integer between {minimum} and {maximum}")
        setattr(config, key, value)

    raw_suppressions = data.get("suppressions", [])
    if not isinstance(raw_suppressions, list):
        raise ConfigurationError("suppressions must be an array of tables")
    for index, item in enumerate(raw_suppressions):
        if not isinstance(item, dict) or set(item) != {"rule", "path", "reason", "expires"}:
            raise ConfigurationError(f"suppressions[{index}] must contain exactly rule, path, reason, expires")
        rule, pattern, reason, expires = (item["rule"], item["path"], item["reason"], item["expires"])
        if not all(isinstance(x, str) and x.strip() for x in (rule, pattern, reason, expires)):
            raise ConfigurationError(f"suppressions[{index}] values must be non-empty strings")
        if rule not in known_rules:
            raise ConfigurationError(f"Unknown suppression rule ID: {rule}")
        normalized_pattern = pattern.replace("\\", "/")
        parsed_pattern = PurePosixPath(normalized_pattern)
        if parsed_pattern.is_absolute() or ".." in parsed_pattern.parts or re.match(r"^[A-Za-z]:", normalized_pattern):
            raise ConfigurationError(f"suppressions[{index}].path must be a repository-relative path/glob")
        try:
            expiry = date.fromisoformat(expires)
        except ValueError as exc:
            raise ConfigurationError(f"suppressions[{index}].expires must use YYYY-MM-DD") from exc
        suppression = Suppression(rule, pattern.replace("\\", "/"), reason.strip(), expiry)
        config.suppressions.append(suppression)
        if expiry < date.today():
            config.warnings.append(f"Expired suppression: {rule} {pattern} (expired {expires}); it is not applied")
    return config
