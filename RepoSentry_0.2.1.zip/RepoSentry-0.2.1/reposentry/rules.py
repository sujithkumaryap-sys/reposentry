"""Bounded local scanning and explainable heuristic rules."""
from dataclasses import dataclass
from fnmatch import fnmatchcase
from pathlib import Path
import os
import re
from reposentry.config import ScanConfig
from reposentry.models import Finding

DEFAULT_IGNORES = {
    ".git", ".hg", ".svn", ".venv", "venv", "node_modules", "__pycache__",
    ".mypy_cache", ".pytest_cache", "dist", "build", "vendor", "coverage",
}
EXTENSIONS = {
    ".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".go", ".rs", ".php",
    ".rb", ".sh", ".ps1", ".yml", ".yaml", ".json", ".toml", ".ini",
    ".cfg", ".conf", ".env", ".tf", ".tfvars", ".xml", ".properties",
    ".html", ".sql", ".md", ".txt", ".dockerfile", ".pem", ".key", ".crt",
}
SPECIAL_NAMES = {".env", "dockerfile", "makefile", "config", "credentials"}

@dataclass(frozen=True)
class Rule:
    rule_id: str
    title: str
    severity: str
    message: str
    recommendation: str

RULES = (
    Rule("RS001", "Possible hard-coded credential assignment", "high",
         "A credential-like assignment contains a non-placeholder value.",
         "Move the value to a secret manager or environment variable; rotate it if real."),
    Rule("RS002", "Private key material", "critical",
         "A private-key PEM header was found.",
         "Remove the key from the repository and rotate/revoke related credentials."),
    Rule("RS003", "TLS verification disabled", "high",
         "TLS certificate verification appears to be disabled.",
         "Enable certificate verification and use a trusted CA bundle where needed."),
    Rule("RS004", "Debug mode enabled", "medium",
         "Debug mode may expose sensitive diagnostics in production.",
         "Ensure debug mode is disabled in production configuration."),
    Rule("RS005", "Permissive CORS policy", "medium",
         "A wildcard CORS origin was configured.",
         "Restrict allowed origins to trusted application domains."),
    Rule("RS006", "Potentially open Terraform ingress", "high",
         "A Terraform ingress block appears to allow traffic from the public internet.",
         "Restrict source CIDRs and ports to the minimum required."),
)
RULE_BY_ID = {rule.rule_id: rule for rule in RULES}

# Bounded, single-line matching. Captured values are never included in findings.
_CREDENTIAL_RE = re.compile(
    r"(?i)(?<![A-Za-z0-9])(?:api[_-]?key|secret[_-]?key|access[_-]?token|auth[_-]?token|password|passwd)\b"
    r"\s*[:=]\s*['\"]?([A-Za-z0-9_./+=:-]{8,256})"
)
_PRIVATE_KEY_RE = re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----")
_TLS_RE = re.compile(r"(?i)(?:\bverify\s*=\s*False\b|\bCERT_NONE\b|\brejectUnauthorized\s*:\s*false\b)")
_DEBUG_RE = re.compile(r"(?i)(?:\bDEBUG\s*=\s*True\b|\bdebug\s*:\s*true\b|\bapp\.run\([^\n)]*\bdebug\s*=\s*True\b)")
_CORS_RE = re.compile(r"(?i)(?:Access-Control-Allow-Origin['\"]?\s*[:=]\s*['\"]\*|allow_origins\s*=\s*\[\s*['\"]\*['\"]\s*\])")
_PLACEHOLDER_WORDS = ("placeholder", "example", "changeme", "change_me", "your_", "replace", "dummy", "fake", "sample", "redacted", "<", "${", "os.", "process.env", "environ", "getenv", "none", "null", "false", "true")

def is_candidate(path: Path) -> bool:
    name = path.name.lower()
    return name in SPECIAL_NAMES or name.startswith(".env.") or path.suffix.lower() in EXTENSIONS

def _is_comment_only(line: str, relative_path: str) -> bool:
    stripped = line.lstrip()
    options = _comment_options(relative_path)
    return ((options["hash_comments"] and stripped.startswith("#")) or
            (options["slash_comments"] and stripped.startswith("//")) or
            (options["sql_comments"] and stripped.startswith("--")) or
            (options["html_comments"] and stripped.startswith("<!--")))

def _brace_blocks(text: str, opener: re.Pattern[str]):
    """Yield ingress blocks in one bounded pass, balancing braces outside strings/comments."""
    openings = {match.end() - 1: match.start() for match in opener.finditer(text)}
    stack = []
    quote = None
    escaped = False
    line_comment = False
    block_comment = False
    i = 0
    while i < len(text):
        ch = text[i]
        nxt = text[i:i+2]
        if line_comment:
            if ch in "\r\n\v\f\x85\u2028\u2029": line_comment = False
        elif block_comment:
            if nxt == "*/": block_comment = False; i += 1
        elif quote:
            if escaped: escaped = False
            elif ch == "\\": escaped = True
            elif ch == quote: quote = None
        elif nxt == "//" or ch == "#":
            line_comment = True
            if nxt == "//": i += 1
        elif nxt == "/*":
            block_comment = True; i += 1
        elif ch in ('"', "'", '`'):
            quote = ch
        elif ch == "{":
            stack.append((i, openings.get(i)))
        elif ch == "}" and stack:
            block_start, ingress_start = stack.pop()
            if not stack and ingress_start is not None:
                yield ingress_start, text[ingress_start:i+1]
            elif ingress_start is not None:
                # An ingress block may be nested inside a resource block.
                yield ingress_start, text[ingress_start:i+1]
        i += 1

_TF_INGRESS_OPEN = re.compile(r"\bingress\s*\{", re.IGNORECASE)

def _strip_line_comments(text: str, *, hash_comments: bool = True, slash_comments: bool = False, block_comments: bool = False, html_comments: bool = False, sql_comments: bool = False) -> str:
    """Blank common source comments outside quoted strings while preserving newlines."""
    out = []
    quote = None
    escaped = False
    line_comment = False
    block_comment = False
    html_comment = False
    i = 0
    while i < len(text):
        ch = text[i]
        nxt = text[i:i+2]
        if line_comment:
            if ch in "\r\n\v\f\x85\u2028\u2029":
                line_comment = False
                out.append(ch)
            else:
                out.append(" ")
            i += 1
        elif html_comment:
            if text[i:i+3] == "-->":
                out.extend("   ")
                html_comment = False
                i += 3
            else:
                out.append(ch if ch in "\r\n\v\f\x85\u2028\u2029" else " ")
                i += 1
        elif block_comment:
            if nxt == "*/":
                out.extend("  ")
                block_comment = False
                i += 2
            else:
                out.append(ch if ch in "\r\n\v\f\x85\u2028\u2029" else " ")
                i += 1
        elif quote:
            out.append(ch)
            if escaped: escaped = False
            elif ch == "\\": escaped = True
            elif ch == quote: quote = None
            i += 1
        elif ch in ('"', "'", '`'):
            quote = ch
            out.append(ch)
            i += 1
        elif html_comments and text[i:i+4] == "<!--":
            html_comment = True
            out.extend("    ")
            i += 4
        elif block_comments and nxt == "/*":
            block_comment = True
            out.extend("  ")
            i += 2
        elif sql_comments and nxt == "--":
            line_comment = True
            out.extend("  ")
            i += 2
        elif hash_comments and ch == "#":
            line_comment = True
            out.append(" ")
            i += 1
        elif slash_comments and nxt == "//":
            line_comment = True
            out.extend("  ")
            i += 2
        else:
            out.append(ch)
            i += 1
    return "".join(out)

def _comment_options(relative_path: str) -> dict[str, bool]:
    suffix = Path(relative_path).suffix.lower()
    name = Path(relative_path).name.lower()
    hash_comments = suffix in {".py", ".sh", ".ps1", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".conf", ".env", ".tf", ".tfvars", ".rb", ".dockerfile", ".sql", ".php"} or name.startswith(".env")
    slash_comments = suffix in {".js", ".jsx", ".ts", ".tsx", ".java", ".go", ".rs", ".php", ".tf", ".tfvars", ".html", ".xml", ".css", ".c", ".h", ".cpp", ".hpp"}
    block_comments = slash_comments or suffix in {".sql"}
    html_comments = suffix in {".html", ".xml", ".md", ".txt"}
    sql_comments = suffix == ".sql"
    if suffix in {".md", ".txt"}:
        hash_comments = False
    return {"hash_comments": hash_comments, "slash_comments": slash_comments,
            "block_comments": block_comments, "html_comments": html_comments,
            "sql_comments": sql_comments}

def _make_finding(rule_id: str, path: str, line: int, config: ScanConfig) -> Finding:
    rule = RULE_BY_ID[rule_id]
    return Finding(rule_id, rule.title, config.severity_overrides.get(rule_id, rule.severity),
                   rule.message, path, max(1, line), rule.recommendation)

def scan_content(content: str, relative_path: str, config: ScanConfig | None = None) -> list[Finding]:
    config = config or ScanConfig()
    # Callers supply repository-relative paths with POSIX separators. Preserve literal
    # backslashes, which are legal filename characters on POSIX systems.
    if any(fnmatchcase(relative_path, pattern.replace("\\", "/")) for pattern in config.ignore_paths):
        return []
    # Strip comments once per file so multiline block/HTML comments remain stateful.
    # Keep original lines for size limits and line numbering.
    lines = content.splitlines()
    commentless = _strip_line_comments(content, **_comment_options(relative_path))
    scan_lines = commentless.splitlines()
    findings = []
    for line_no, (raw_line, line) in enumerate(zip(lines, scan_lines), start=1):
        if len(raw_line) > config.max_line_chars or _is_comment_only(raw_line, relative_path):
            continue
        if config.rule_enabled("RS001"):
            match = _CREDENTIAL_RE.search(line)
            if match:
                value = match.group(1).strip("'\" ").lower()
                if not any(word in value for word in _PLACEHOLDER_WORDS):
                    findings.append(_make_finding("RS001", relative_path, line_no, config))
        if config.rule_enabled("RS003") and _TLS_RE.search(line):
            findings.append(_make_finding("RS003", relative_path, line_no, config))
        if config.rule_enabled("RS004") and _DEBUG_RE.search(line):
            findings.append(_make_finding("RS004", relative_path, line_no, config))
        if config.rule_enabled("RS005") and _CORS_RE.search(line):
            findings.append(_make_finding("RS005", relative_path, line_no, config))
    if config.rule_enabled("RS002"):
        for match in _PRIVATE_KEY_RE.finditer(commentless):
            line = commentless.count("\n", 0, match.start()) + 1
            findings.append(_make_finding("RS002", relative_path, line, config))
    if config.rule_enabled("RS006") and relative_path.lower().endswith((".tf", ".tfvars")):
        for start, block in _brace_blocks(commentless, _TF_INGRESS_OPEN):
            public_cidr_assignment = re.search(
                r"(?is)\b(?:cidr_blocks|ipv6_cidr_blocks|source_ranges)\s*=\s*\[[^\]]*(?:0\.0\.0\.0/0|::/0)[^\]]*\]", block
            )
            if public_cidr_assignment:
                line = commentless.count("\n", 0, start) + 1
                findings.append(_make_finding("RS006", relative_path, line, config))
    filtered = []
    for finding in findings:
        suppression = config.suppression_for(finding.rule_id, finding.path)
        if suppression is None:
            filtered.append(finding)
    # Dedupe same rule/path/line and make order deterministic.
    unique = {(f.rule_id, f.path, f.line): f for f in filtered}
    return sorted(unique.values(), key=lambda f: (f.path.casefold(), f.line, f.rule_id))

def _safe_read_detailed(path: Path, root: Path, max_bytes: int) -> tuple[str | None, str | None]:
    try:
        if path.is_symlink():
            return None, "symbolic link"
        resolved = path.resolve(strict=True)
        if not resolved.is_relative_to(root.resolve()):
            return None, "path resolves outside scan root"
        stat = path.stat()
        if not path.is_file():
            return None, "not a regular file"
        if stat.st_size > max_bytes:
            return None, f"file exceeds {max_bytes}-byte limit"
        with path.open("rb") as stream:
            raw = stream.read(max_bytes + 1)
        if len(raw) > max_bytes:
            return None, f"file exceeds {max_bytes}-byte limit while reading"
        if b"\x00" in raw:
            return None, "binary content"
        return raw.decode("utf-8-sig", errors="strict"), None
    except UnicodeError:
        return None, "invalid UTF-8 encoding"
    except (OSError, RuntimeError) as exc:
        return None, f"read failed ({type(exc).__name__})"

def _safe_read(path: Path, root: Path, max_bytes: int) -> str | None:
    return _safe_read_detailed(path, root, max_bytes)[0]

def scan_path_detailed(target: Path, ignores: set[str] | None = None, allow_rules: set[str] | None = None,
                       allow_paths: set[str] | None = None, config: ScanConfig | None = None) -> tuple[list[Finding], list[str]]:
    config = config or ScanConfig()
    target = Path(target)
    if target.is_symlink():
        raise OSError("Refusing to scan a symbolic-link target directly")
    target = target.resolve()
    if not target.exists():
        raise FileNotFoundError(f"Path does not exist: {target}")
    root = target if target.is_dir() else target.parent
    ignored_names = DEFAULT_IGNORES if ignores is None else ignores
    allowed_rules = allow_rules or set()
    allowed_paths = {p.replace("\\", "/") for p in (allow_paths or set())}
    warnings: list[str] = []
    if target.is_file():
        candidates = [target]
    else:
        candidates = []
        def walk_error(exc):
            try:
                failed_path = Path(exc.filename).relative_to(root).as_posix()
            except (TypeError, ValueError):
                failed_path = "<unknown path>"
            warnings.append(f"Could not traverse {failed_path} ({type(exc).__name__})")
        for current, dirs, names in os.walk(target, followlinks=False, onerror=walk_error):
            retained_dirs = []
            for name in dirs:
                directory = Path(current) / name
                if name in ignored_names:
                    continue
                if directory.is_symlink():
                    warnings.append(f"Skipped symlink directory: {directory.relative_to(root).as_posix()}")
                    continue
                retained_dirs.append(name)
            dirs[:] = retained_dirs
            for name in names:
                candidate = Path(current) / name
                if not is_candidate(candidate):
                    continue
                try:
                    relative_candidate = candidate.relative_to(root).as_posix()
                except ValueError:
                    continue
                if any(fnmatchcase(relative_candidate, pattern.replace("\\", "/")) for pattern in config.ignore_paths):
                    continue
                if candidate.is_symlink():
                    warnings.append(f"Skipped symlink file: {relative_candidate}")
                    continue
                candidates.append(candidate)
                if len(candidates) > config.max_files:
                    raise OSError(f"Scan file limit exceeded ({config.max_files}); narrow the target or configure scan.max_files")
    findings = []
    bytes_scanned = 0
    for path in sorted(candidates, key=lambda p: p.as_posix().casefold()):
        try:
            relative = path.relative_to(root).as_posix()
        except ValueError:
            continue
        if any(fnmatchcase(relative, pattern.replace("\\", "/")) for pattern in config.ignore_paths):
            continue
        if relative in allowed_paths:
            continue
        content, read_warning = _safe_read_detailed(path, root, config.max_file_bytes)
        if content is None:
            if read_warning:
                warnings.append(f"Skipped {relative}: {read_warning}")
            continue
        bytes_scanned += len(content.encode("utf-8", "surrogateescape"))
        if bytes_scanned > config.max_total_bytes:
            raise OSError(f"Total scan byte limit exceeded ({config.max_total_bytes}); narrow the target or configure scan.max_total_bytes")
        long_lines = sum(1 for line in content.splitlines() if len(line) > config.max_line_chars)
        if long_lines:
            warnings.append(f"Skipped {long_lines} overlong line(s) in {relative} (limit {config.max_line_chars} characters per line)")
        findings.extend(f for f in scan_content(content, relative, config) if f.rule_id not in allowed_rules)
    unique = {(f.rule_id, f.path, f.line): f for f in findings}
    return sorted(unique.values(), key=lambda f: (f.path.casefold(), f.line, f.rule_id)), sorted(set(warnings))

def scan_path(target: Path, ignores: set[str] | None = None, allow_rules: set[str] | None = None,
              allow_paths: set[str] | None = None, config: ScanConfig | None = None) -> list[Finding]:
    """Backward-compatible findings-only wrapper; CLI uses detailed diagnostics."""
    return scan_path_detailed(target, ignores, allow_rules, allow_paths, config)[0]
